use kevala::{
    json::Value,
    kernels::Mat,
    pack::{TensorInfo, Writer},
    store::{AlignedBuf, Store},
};
use std::{cell::RefCell, hint::black_box};

struct Fixture {
    store: Store,
    tensor: TensorInfo,
    ids: Vec<usize>,
    out: Vec<f32>,
    width: usize,
}
thread_local! { static STATE: RefCell<Option<Fixture>> = const { RefCell::new(None) }; }

#[inline(never)]
fn actual_row(store: &Store, tensor: &TensorInfo, row: usize, out: &mut [f32]) {
    store.row(tensor, row, out);
}

#[no_mangle]
pub extern "C" fn row_bench_prepare(k: usize, block: usize, tokens: usize, width: usize) -> u32 {
    if k == 0 || block == 0 || block % 16 != 0 || k % block != 0 || width > k || tokens == 0 {
        return 1;
    }
    let rows = 512;
    let mut writer = Writer::new(Value::Null, Value::Null, vec![]);
    writer.add_q8("embedding", rows, k, block);
    let (_, infos, total) = writer.layout();
    let tensor = infos[0].clone();
    let mut buf = AlignedBuf::new(total);
    for i in 0..tensor.size {
        buf.as_mut_slice()[tensor.offset + i] = i.wrapping_mul(73).wrapping_add(19) as u8;
    }
    for i in 0..tensor.scales_size / 4 {
        let offset = tensor.scales_offset + i * 4;
        buf.as_mut_slice()[offset..offset + 4].copy_from_slice(&(((i % 59 + 1) as f32) / 4096.).to_le_bytes());
    }
    let store = Store::new(buf, infos).unwrap();
    let ids = (0..tokens).map(|i| (i * 7919 + 43) % rows).collect();
    STATE.with_borrow_mut(|state| *state = Some(Fixture { store, tensor, ids, out: vec![0.; tokens * width], width }));
    0
}

#[no_mangle]
pub extern "C" fn row_bench_verify() -> u32 {
    STATE.with_borrow_mut(|state| {
        let f = state.as_mut().unwrap();
        let Mat::Q8 { k, block, q, scales, .. } = f.store.mat(&f.tensor) else { unreachable!() };
        let nb = k / block;
        for (token, &id) in f.ids.iter().enumerate() {
            let out = &mut f.out[token * f.width..(token + 1) * f.width];
            actual_row(&f.store, &f.tensor, id, out);
            for (c, value) in out.iter().enumerate() {
                let expected = q[id * k + c] as f32 * scales[id * nb + c / block];
                if value.to_bits() != expected.to_bits() {
                    return 1;
                }
            }
        }
        0
    })
}

#[no_mangle]
pub extern "C" fn row_bench_run(repetitions: usize) {
    STATE.with_borrow_mut(|state| {
        let f = state.as_mut().unwrap();
        for _ in 0..repetitions {
            for (token, &id) in f.ids.iter().enumerate() {
                let out = &mut f.out[token * f.width..(token + 1) * f.width];
                actual_row(black_box(&f.store), black_box(&f.tensor), black_box(id), black_box(out));
            }
        }
        black_box(&f.out);
    });
}

#[no_mangle]
pub extern "C" fn row_bench_out_ptr() -> *const f32 {
    STATE.with_borrow(|state| state.as_ref().unwrap().out.as_ptr())
}

#[no_mangle]
pub extern "C" fn row_bench_out_len() -> usize {
    STATE.with_borrow(|state| state.as_ref().unwrap().out.len())
}
