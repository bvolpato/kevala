use std::{
    ffi::{c_char, c_void, CStr, CString},
    time::Instant,
};

#[link(name = "dl")]
extern "C" {
    fn dlopen(path: *const c_char, flags: i32) -> *mut c_void;
    fn dlsym(handle: *mut c_void, name: *const c_char) -> *mut c_void;
    fn dlerror() -> *const c_char;
    fn dlclose(handle: *mut c_void) -> i32;
}

struct Library {
    handle: *mut c_void,
    prepare: unsafe extern "C" fn(usize, usize, usize, usize) -> u32,
    verify: unsafe extern "C" fn() -> u32,
    run: unsafe extern "C" fn(usize),
    out_ptr: unsafe extern "C" fn() -> *const f32,
    out_len: unsafe extern "C" fn() -> usize,
}

impl Library {
    unsafe fn open(path: &str) -> Self {
        let handle = dlopen(CString::new(path).unwrap().as_ptr(), 2); // RTLD_NOW | RTLD_LOCAL
        assert!(!handle.is_null(), "dlopen: {}", CStr::from_ptr(dlerror()).to_string_lossy());
        let symbol = |name: &str| {
            let p = dlsym(handle, CString::new(name).unwrap().as_ptr());
            assert!(!p.is_null(), "missing {name}");
            p
        };
        Self {
            handle,
            prepare: std::mem::transmute::<*mut c_void, unsafe extern "C" fn(usize, usize, usize, usize) -> u32>(
                symbol("row_bench_prepare"),
            ),
            verify: std::mem::transmute::<*mut c_void, unsafe extern "C" fn() -> u32>(symbol("row_bench_verify")),
            run: std::mem::transmute::<*mut c_void, unsafe extern "C" fn(usize)>(symbol("row_bench_run")),
            out_ptr: std::mem::transmute::<*mut c_void, unsafe extern "C" fn() -> *const f32>(symbol(
                "row_bench_out_ptr",
            )),
            out_len: std::mem::transmute::<*mut c_void, unsafe extern "C" fn() -> usize>(symbol("row_bench_out_len")),
        }
    }

    unsafe fn output(&self) -> &[f32] {
        std::slice::from_raw_parts((self.out_ptr)(), (self.out_len)())
    }
}

impl Drop for Library {
    fn drop(&mut self) {
        unsafe { dlclose(self.handle) };
    }
}

fn verify(libs: &[Library; 2], k: usize, block: usize, tokens: usize, width: usize) -> u64 {
    unsafe {
        for lib in libs {
            assert_eq!((lib.prepare)(k, block, tokens, width), 0);
            assert_eq!((lib.verify)(), 0, "k={k} block={block} tokens={tokens} width={width}");
        }
        if width != 0 {
            assert_ne!((libs[0].out_ptr)(), (libs[1].out_ptr)(), "libraries must have distinct fixture state");
        }
        let (a, b) = (libs[0].output(), libs[1].output());
        assert_eq!(a.len(), b.len());
        let mut digest = 0xcbf2_9ce4_8422_2325u64;
        for (i, (a, b)) in a.iter().zip(b).enumerate() {
            assert_eq!(a.to_bits(), b.to_bits(), "baseline/candidate differ at {i}");
            digest = (digest ^ a.to_bits() as u64).wrapping_mul(0x0000_0100_0000_01b3);
        }
        digest
    }
}

fn main() {
    let args: Vec<String> = std::env::args().skip(1).collect();
    assert!(args.len() >= 2, "usage: bench BASELINE.so CANDIDATE.so [--time] [--tails]");
    let timed = args.iter().any(|a| a == "--time");
    let tails = args.iter().any(|a| a == "--tails");
    if timed {
        let canonical = format!("{}/.cache/kevala/gpu-profile.lock", std::env::var("HOME").unwrap());
        assert_eq!(std::env::var("KEVALA_PROFILE_LOCK_HELD").as_deref(), Ok(canonical.as_str()));
        assert!(std::arch::is_x86_feature_detected!("avx2"), "AVX2 timing requires AVX2 hardware");
    }
    let libs = unsafe { [Library::open(&args[0]), Library::open(&args[1])] };
    println!(
        "{{\"type\":\"host\",\"avx2\":{},\"timed\":{timed},\"tails\":{tails}}}",
        std::arch::is_x86_feature_detected!("avx2")
    );
    for k in [1024, 2560, 4096] {
        for block in if timed && !tails { vec![32] } else { vec![16, 32, 64] } {
            for tokens in [1, 158, 659] {
                let widths = if !timed {
                    vec![0, 1, 5, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 128, k - 1, k]
                } else if tails {
                    vec![5, 17, 63, 64, 128, k]
                } else {
                    vec![k]
                };
                for width in widths {
                    let digest = verify(&libs, k, block, tokens, width);
                    if !timed {
                        println!("{{\"type\":\"verified\",\"k\":{k},\"block\":{block},\"tokens\":{tokens},\"width\":{width},\"bitsDigest\":\"{digest:016x}\"}}");
                        continue;
                    }
                    let repetitions = (33_554_432usize / (tokens * width)).clamp(1, 65_536);
                    for _ in 0..3 {
                        for lib in &libs {
                            unsafe { (lib.run)(repetitions) };
                        }
                    }
                    let mut rounds = Vec::new();
                    for round in 0..9 {
                        let order = if round % 2 == 0 { [0, 1, 1, 0] } else { [1, 0, 0, 1] };
                        let mut samples = [0u128; 4];
                        for (sample, variant) in order.into_iter().enumerate() {
                            let start = Instant::now();
                            unsafe { (libs[variant].run)(repetitions) };
                            samples[sample] = start.elapsed().as_nanos();
                        }
                        rounds.push(samples);
                    }
                    let mut ratios: Vec<f64> = rounds
                        .iter()
                        .enumerate()
                        .map(|(r, s)| {
                            let (a, b) =
                                if r % 2 == 0 { (s[0] + s[3], s[1] + s[2]) } else { (s[1] + s[2], s[0] + s[3]) };
                            a as f64 / b as f64
                        })
                        .collect();
                    ratios.sort_by(f64::total_cmp);
                    println!("{{\"type\":\"timing\",\"k\":{k},\"block\":{block},\"tokens\":{tokens},\"width\":{width},\"repetitions\":{repetitions},\"rowCallsPerSample\":{},\"bitsDigest\":\"{digest:016x}\",\"roundsNs\":{rounds:?},\"medianSpeedup\":{}}}", repetitions * tokens, ratios[ratios.len() / 2]);
                    // Recheck the exact output bits after the timed calls.
                    unsafe {
                        assert!(libs[0].output().iter().zip(libs[1].output()).all(|(a, b)| a.to_bits() == b.to_bits()));
                    }
                }
            }
        }
    }
}
