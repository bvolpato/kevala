import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = dirname(fileURLToPath(import.meta.url));
const toolchain = '/home/bruno/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin';
const source = JSON.parse(readFileSync(join(root, 'frozen-source.json')));
const hash = path => createHash('sha256').update(readFileSync(path)).digest('hex');
for (const [path, expected] of Object.entries(source.sourceHashes)) {
  if (hash(join(root, 'frozen-v1', path)) !== expected) throw new Error(`source changed: ${path}`);
}
const binaries = Object.fromEntries(['baseline', 'candidate'].flatMap(variant => {
  return ['libq8_row_avx2_bench.so', 'q8-row-avx2-bench'].map(name => {
    const path = join(root, 'target', variant, 'release', name);
    if (!existsSync(path)) throw new Error(`missing binary: ${path}`);
    return [path, hash(path)];
  });
}));
const receipt = {
  sourceReceiptSha256: hash(join(root, 'frozen-source.json')),
  rustc: execFileSync(join(toolchain, 'rustc'), ['-Vv']).toString(),
  cargo: execFileSync(join(toolchain, 'cargo'), ['-V']).toString().trim(),
  rustflags: null,
  encodedRustflags: null,
  binaries,
};
writeFileSync(join(root, 'built-receipt.json'), `${JSON.stringify(receipt, null, 2)}\n`);
console.log(JSON.stringify(receipt, null, 2));
