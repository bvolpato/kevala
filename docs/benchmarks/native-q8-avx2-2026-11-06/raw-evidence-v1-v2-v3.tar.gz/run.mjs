import { spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import os from 'node:os';

const root = dirname(fileURLToPath(import.meta.url));
const phase = process.argv[2];
const version = process.argv[3] ?? 'v1';
if (!/^v\d+$/.test(version)) throw new Error(`invalid version: ${version}`);
const target = version === 'v1' ? join(root, 'target') : join(root, `target/${version}`);
const frozen = join(root, `frozen-${version}`);
const sourceReceipt = join(root, version === 'v1' ? 'frozen-source.json' : `frozen-source-${version}.json`);
const out = join(root, `runs-${version}`);
mkdirSync(out, { recursive: true });
const toolchain = '/home/bruno/.rustup/toolchains/1.95.0-x86_64-unknown-linux-gnu/bin';
const env = { ...process.env, RUSTC: join(toolchain, 'rustc'), RUSTDOC: join(toolchain, 'rustdoc') };
delete env.RUSTFLAGS;
delete env.CARGO_ENCODED_RUSTFLAGS;
env.KEVALA_PROFILE_LOCK_HELD = '/home/bruno/.cache/kevala/gpu-profile.lock';
const run = (name, bin, args = [], overrides = {}, expectedStatus = 0) => {
  const started = new Date().toISOString();
  const result = spawnSync(bin, args, { cwd: '/tmp/kevala-native-q8-avx2', env: { ...env, ...overrides }, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  writeFileSync(join(out, `${name}.stdout`), result.stdout ?? '');
  writeFileSync(join(out, `${name}.stderr`), result.stderr ?? '');
  const receipt = { started, ended: new Date().toISOString(), bin, args, cwd: '/tmp/kevala-native-q8-avx2', overrides: { RUSTC: env.RUSTC, RUSTDOC: env.RUSTDOC, RUSTFLAGS: null, CARGO_ENCODED_RUSTFLAGS: null, ...overrides }, expectedStatus, status: result.status, signal: result.signal, error: result.error?.message };
  writeFileSync(join(out, `${name}.command.json`), `${JSON.stringify(receipt, null, 2)}\n`);
  console.log(JSON.stringify(receipt));
  if (typeof expectedStatus === 'string' ? result.signal !== expectedStatus : result.status !== expectedStatus) {
    process.stdout.write(result.stdout ?? '');
    process.stderr.write(result.stderr ?? '');
    process.exit(result.status ?? 1);
  }
  return result.stdout;
};

if (phase === 'metadata') {
  run('rustc', join(toolchain, 'rustc'), ['-Vv']);
  run('cargo', join(toolchain, 'cargo'), ['-V']);
  run('cpu', 'lscpu');
  run('topology', 'lscpu', ['-e=CPU,CORE,SOCKET,NODE,ONLINE']);
  run('affinity', 'taskset', ['-pc', `${process.pid}`]);
  run('locks', 'sh', ['-c', "lslocks -o PID,COMMAND,TYPE,MODE,PATH | rg 'kevala/gpu-profile.lock'"]);
  const sample = () => readFileSync('/proc/stat', 'utf8').split('\n').filter(line => /^cpu\d+ /.test(line)).map(line => {
    const [cpu, ...fields] = line.trim().split(/\s+/);
    const values = fields.map(Number);
    return { cpu, total: values.slice(0, 8).reduce((a, b) => a + b, 0), idle: values[3] + values[4] };
  });
  const first = sample();
  await new Promise(resolve => setTimeout(resolve, 500));
  const usage = sample().map((value, i) => ({ cpu: value.cpu, utilization: 1 - (value.idle - first[i].idle) / (value.total - first[i].total) }));
  const metadata = { timestamp: new Date().toISOString(), loadavg: os.loadavg(), allowed: readFileSync('/proc/self/status', 'utf8').match(/^Cpus_allowed_list:\s*(.*)$/m)[1], selectedCpu: 7, usage, procStat: readFileSync('/proc/stat', 'utf8'), chosenCpuGovernor: readFileSync('/sys/devices/system/cpu/cpu7/cpufreq/scaling_governor', 'utf8').trim() };
  writeFileSync(join(out, 'metadata.json'), `${JSON.stringify(metadata, null, 2)}\n`);
  console.log(JSON.stringify(metadata));
} else if (phase === 'test') {
  run('focused-test', join(toolchain, 'cargo'), ['test', '--locked', '--offline', '--manifest-path', '/tmp/kevala-native-q8-avx2/Cargo.toml', '-p', 'kevala', 'q8_'], { CARGO_TARGET_DIR: join(target, 'test') });
} else if (phase === 'build' || phase === 'receipt') {
  if (phase === 'build') {
    for (const variant of ['baseline', 'candidate']) {
      run(`build-${variant}`, join(toolchain, 'cargo'), ['build', '--release', '--offline', '--locked', '--manifest-path', join(frozen, `${variant}/tmp/q8-row-avx2-bench/Cargo.toml`)], { CARGO_TARGET_DIR: join(target, variant) });
    }
  }
  const source = JSON.parse(readFileSync(sourceReceipt));
  const hash = path => createHash('sha256').update(readFileSync(path)).digest('hex');
  for (const [path, expected] of Object.entries(source.sourceHashes)) {
    if (hash(join(frozen, path)) !== expected) throw new Error(`source changed: ${path}`);
  }
  const binaries = Object.fromEntries(['baseline', 'candidate'].flatMap(variant => ['libq8_row_avx2_bench.so', 'q8-row-avx2-bench'].map(name => {
    const path = join(target, `${variant}/release`, name);
    return [path, hash(path)];
  })));
  writeFileSync(join(out, 'built-receipt.json'), `${JSON.stringify({ sourceReceiptSha256: hash(sourceReceipt), binaries, rustc: readFileSync(join(out, 'rustc.stdout'), 'utf8'), cargo: readFileSync(join(out, 'cargo.stdout'), 'utf8'), rustflags: null, encodedRustflags: null }, null, 2)}\n`);
} else if (phase === 'assembly') {
  for (const variant of ['baseline', 'candidate']) {
    const lib = join(target, `${variant}/release/libq8_row_avx2_bench.so`);
    run(`symbols-${variant}`, 'nm', ['-anC', lib]);
    run(`assembly-${variant}`, 'objdump', ['-Cd', lib]);
  }
} else if (['verify', 'screen', 'tails', 'guard'].includes(phase)) {
  const args = [join(target, 'candidate/release/q8-row-avx2-bench'), join(target, 'baseline/release/libq8_row_avx2_bench.so'), join(target, 'candidate/release/libq8_row_avx2_bench.so')];
  if (phase !== 'verify') args.push('--time');
  if (phase === 'tails') args.push('--tails');
  writeFileSync(join(out, `${phase}-before.json`), `${JSON.stringify({ timestamp: new Date().toISOString(), loadavg: os.loadavg(), procStat: readFileSync('/proc/stat', 'utf8') }, null, 2)}\n`);
  if (phase === 'guard') {
    run(phase, 'env', ['-u', 'KEVALA_PROFILE_LOCK_HELD', 'taskset', '-c', '7', ...args], {}, 'SIGABRT');
    const stdout = readFileSync(join(out, 'guard.stdout'), 'utf8');
    const stderr = readFileSync(join(out, 'guard.stderr'), 'utf8');
    if (stdout !== '' || !stderr.includes('Err(NotPresent)') || !stderr.includes(env.KEVALA_PROFILE_LOCK_HELD)) throw new Error('guard did not reject absent lock environment');
  } else {
    run(phase, 'taskset', ['-c', '7', ...args]);
  }
  writeFileSync(join(out, `${phase}-after.json`), `${JSON.stringify({ timestamp: new Date().toISOString(), loadavg: os.loadavg(), procStat: readFileSync('/proc/stat', 'utf8') }, null, 2)}\n`);
} else {
  throw new Error(`unknown phase: ${phase}`);
}
