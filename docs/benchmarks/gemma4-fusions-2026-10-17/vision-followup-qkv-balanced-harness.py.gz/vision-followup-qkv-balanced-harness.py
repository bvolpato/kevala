#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12"
# dependencies = ["playwright==1.63.0"]
# ///
"""Measure joint BF16 vision Q/K/V fusion in sixteen balanced ABBA camera blocks.

Serve the local decoder, companion, and paired proxy first. Run only one large
model benchmark at a time. This measures throughput, preprocessing counts,
preview cadence, and camera lifecycle, not expression accuracy.
"""

from __future__ import annotations

import argparse
import json
import math
import signal
import tempfile
import time
from pathlib import Path

from playwright.sync_api import sync_playwright


BLOCK_MODES = ["off", "on", "on", "off"] * 4
MEASURED_PER_BLOCK = 60
WARMUPS_PER_BLOCK = [124] + [4] * 15
JOB_SECONDS = 120
MEMORY_CAP_BYTES = 6 * 1024**3


def percentile(values, fraction):
    ordered = sorted(values)
    return ordered[max(0, min(len(ordered) - 1, math.ceil(fraction * len(ordered)) - 1))] if ordered else None


def summarize(values):
    values = [value for value in values if isinstance(value, (int, float))]
    if not values:
        return None
    ordered = sorted(values)
    return {
        "p50Ms": (ordered[(len(values) - 1) // 2] + ordered[len(values) // 2]) / 2,
        "p95Ms": percentile(values, 0.95),
        "meanMs": sum(values) / len(values),
        "samples": len(values),
    }


def cgroup_resources():
    cgroup_path = Path("/proc/self/cgroup")
    if not cgroup_path.exists():
        return None
    group = next((line.removeprefix("0::") for line in cgroup_path.read_text().splitlines() if line.startswith("0::")), None)
    if not group:
        return None
    directory = Path("/sys/fs/cgroup") / group.lstrip("/")
    names = ["memory.high", "memory.max", "memory.peak", "memory.events", "memory.swap.max", "cpu.max", "cpu.stat"]
    return {name: (directory / name).read_text().strip() for name in names if (directory / name).exists()}


def aggregate_blocks(phases):
    by_mode = {}
    for mode in ["off", "on"]:
        blocks = [phase for phase in phases if phase["mode"] == mode]
        samples = [row for phase in blocks for row in phase["samples"][phase["warmupFrames"]:]]
        measured_ms = sum(phase["summary"]["measuredSpanMs"] for phase in blocks)
        by_mode[mode] = {
            "blocks": len(blocks),
            "measuredDecisions": len(samples),
            "discardedWarmups": sum(phase["warmupFrames"] for phase in blocks),
            "measuredSpanMs": measured_ms,
            "completedFps": len(samples) * 1000 / measured_ms,
            "completionTimePerDecisionMs": measured_ms / len(samples),
            "decisionWall": summarize([row["elapsedMs"] for row in samples]),
        }
    quads = []
    for start in range(0, len(phases), 4):
        blocks = phases[start:start + 4]
        if [phase["mode"] for phase in blocks] != ["off", "on", "on", "off"]:
            raise RuntimeError("the balanced ABBA block order changed")
        wall = {mode: sum(phase["summary"]["decisionWall"]["meanMs"] for phase in blocks if phase["mode"] == mode) / 2 for mode in ["off", "on"]}
        completion = {mode: sum(phase["summary"]["completionTimePerDecisionMs"] for phase in blocks if phase["mode"] == mode) / 2 for mode in ["off", "on"]}
        quads.append({
            "quad": start // 4,
            "blocks": list(range(start, start + 4)),
            "offBlockMeanDecisionWallMs": wall["off"],
            "onBlockMeanDecisionWallMs": wall["on"],
            "offMinusOnMeanDecisionWallMs": wall["off"] - wall["on"],
            "offBlockMeanCompletionTimePerDecisionMs": completion["off"],
            "onBlockMeanCompletionTimePerDecisionMs": completion["on"],
            "offMinusOnCompletionTimePerDecisionMs": completion["off"] - completion["on"],
        })
    return {
        "byMode": by_mode,
        "balancedQuads": quads,
        "meanQuadOffMinusOnDecisionWallMs": sum(quad["offMinusOnMeanDecisionWallMs"] for quad in quads) / len(quads),
        "meanQuadOffMinusOnCompletionTimePerDecisionMs": sum(quad["offMinusOnCompletionTimePerDecisionMs"] for quad in quads) / len(quads),
        "method": "Completed FPS pools within-block measured spans and excludes inter-block stop/start time. Positive off-minus-on values favor the candidate. Quad effects are point estimates; no statistical confidence is inferred.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://127.0.0.1:18102/")
    parser.add_argument("--binary", required=True, type=Path)
    parser.add_argument("--browser-arg", action="append", default=[])
    parser.add_argument("--frames", type=int, choices=[MEASURED_PER_BLOCK], default=MEASURED_PER_BLOCK, help="measured decisions per block; the balanced design uses 60")
    parser.add_argument("--kernel", choices=["auto", "generic", "wide"], default="auto")
    parser.add_argument("--camera-fps", type=int, default=60)
    parser.add_argument("--budget", choices=[16], type=int, default=16)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    if args.camera_fps < 1 or args.camera_fps > 120:
        parser.error("--camera-fps must be between 1 and 120")
    output = {"status": "running", "source": "Chromium synthetic camera", "experiment": "joint BF16 vision Q/K/V fusion balanced ABBA x4", "kernel": args.kernel, "budget": args.budget,
        "blockModes": BLOCK_MODES, "measuredFramesPerBlock": args.frames, "measuredFramesPerMode": 8 * args.frames,
        "discardedWarmupsPerBlock": WARMUPS_PER_BLOCK, "additionalFirstBlockWarmups": 120,
        "totalDiscardedWarmups": sum(WARMUPS_PER_BLOCK), "requestedCameraFps": args.camera_fps,
        "jobDeadlineSeconds": JOB_SECONDS, "requiredMemoryMaxBytes": MEMORY_CAP_BYTES}
    started = time.monotonic()
    def remaining_ms(maximum=30000):
        remaining = int((JOB_SECONDS - (time.monotonic() - started)) * 1000)
        if remaining <= 0:
            raise TimeoutError("camera benchmark 120-second overall deadline exceeded")
        return min(maximum, remaining)
    def deadline(_signum, _frame):
        raise TimeoutError("camera benchmark 120-second overall deadline exceeded")
    previous_handler = signal.signal(signal.SIGALRM, deadline)
    signal.setitimer(signal.ITIMER_REAL, JOB_SECONDS)
    try:
        resources = cgroup_resources()
        memory_max = (resources or {}).get("memory.max", "max")
        if not memory_max.isdigit() or int(memory_max) > MEMORY_CAP_BYTES:
            raise RuntimeError("run this benchmark in a cgroup with memory.max <= 6 GiB; the browser was not started")
        output["initialResourceSnapshot"] = resources
        with sync_playwright() as playwright, tempfile.TemporaryDirectory(prefix="kevala-camera-") as profile:
            context = playwright.chromium.launch_persistent_context(
                profile, executable_path=str(args.binary), headless=True,
                timeout=remaining_ms(120000),
                permissions=["camera"],
                args=[f"--use-fake-device-for-media-stream=fps={args.camera_fps}", "--use-fake-ui-for-media-stream", *args.browser_arg],
            )
            try:
                context.set_default_timeout(remaining_ms())
                page = context.pages[0]
                errors = []
                page.on("pageerror", lambda error: errors.append(str(error)))
                page.goto(args.base_url.rstrip("/") + "/?model=gemma-4-e2b&backend=webgpu#/reaction", timeout=remaining_ms())
                page.evaluate("""async kernel => {
                  const {Kevala}=await import('./js/src/index.js');
                  const load=Kevala.load.bind(Kevala);
                  Kevala.load=options=>load({...options,gpuKernel:kernel,profile:false});
                  const {session}=await import('./app/session.js');
                  window.benchSession=session; await session.boot();
                  session.select('gemma-4-e2b', {enableVision:true});
                }""", args.kernel)
                page.locator(".mchip").click()
                page.locator('[data-act="load"]').click()
                page.wait_for_function("() => ['ready','error'].includes(window.benchSession.status)", timeout=remaining_ms(120000))
                info = page.evaluate("async () => {const {session}=await import('./app/session.js');if(!session.ready)throw new Error(session.error);return session.info;}")
                if info["backend"] != "webgpu" or "image" not in info["modalities"]:
                    raise RuntimeError("the loaded model lacks WebGPU image support")
                page.locator(".mchip").click()
                page.evaluate("""async () => {
                  const {session}=await import('./app/session.js');
                  const model=session.kevala, decide=model.decide.bind(model);
                  window.cameraBench={model,samples:[],streams:[],preview:{},currentPhase:null,inFlight:0,maxInFlight:0,
                    prefixKeys:['narrowPrefixMatrices','prefixGeluFusions','retiledPrefixMatrices','sharedMatvecMatrices','rmsNextFusions']};
                  const getUserMedia=navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
                  navigator.mediaDevices.getUserMedia=async (...args)=>{
                    const stream=await getUserMedia(...args);window.cameraBench.streams.push(stream);return stream;
                  };
                  const video=document.querySelector('[data-f="video"]');
                  if(typeof video.requestVideoFrameCallback!=='function')throw new Error('requestVideoFrameCallback is required to measure preview cadence');
                  video.addEventListener('playing',()=>{
                    const b=window.cameraBench,phase=b.currentPhase;
                    if(phase===null||b.preview[phase]?.watching)return;
                    const bucket=b.preview[phase] ||= {timestamps:[],presentedFrames:0,droppedTimestamps:0,watching:true};
                    const record=(now,metadata)=>{
                      if(b.currentPhase!==phase||!video.srcObject?.active)return;
                      bucket.timestamps.push(metadata.expectedDisplayTime||now);
                      if(bucket.timestamps.length>4096){bucket.timestamps.shift();bucket.droppedTimestamps++;}
                      bucket.presentedFrames=metadata.presentedFrames||bucket.presentedFrames;
                      video.requestVideoFrameCallback(record);
                    };
                    video.requestVideoFrameCallback(record);
                  });
                  const selectedTuning=()=>JSON.stringify(model.info?.gpuTuning||{});
                  window.cameraBench.selectedTuning=selectedTuning();
                  model.decide=async (state,questions,options)=>{
                    const b=window.cameraBench, start=performance.now();
                    let hash=2166136261;
                    const pixels=options.parts[0].data.data;
                    for(let i=0;i<pixels.length;i+=97)hash=Math.imul(hash^pixels[i],16777619);
                    b.inFlight++;b.maxInFlight=Math.max(b.maxInFlight,b.inFlight);
                    try {
                      const result=await decide(state,questions,options);
                      const completedAt=performance.now();
                      const timing=result.timing||{},compact=timing.experimental?.visionQkv||null,reuse=timing.prefixReuse||{};
                      const image=timing.image||{};
                      const stageTiming=Object.fromEntries(['decode','preprocess','forward','images','patches','softTokens','forwardMode','attention','fusedPasses','compactPreprocesses'].filter(key=>image[key]!==undefined).map(key=>[key,image[key]]));
                      const prefixReuse=Object.fromEntries(b.prefixKeys.map(key=>[key,Number.isFinite(reuse[key])?reuse[key]:null]));
                      const visionFusion=timing.experimental?.vision||null;
                      const visionQkv=compact?{enabled:compact.enabled,submitMode:compact.submitMode,
                        fusionCount:compact.fusionCount,imageCount:compact.imageCount,actualRows:compact.actualRows,actualSoftRows:compact.actualSoftRows,paddedPatchMetadata:compact.paddedPatchMetadata,
                        batchMlpState:compact.batchMlpState||null,kernelSelectionState:compact.kernelSelectionState?{
                          ...compact.kernelSelectionState,attentionSelection:compact.attentionSelection,
                          unrelatedRuntimeFlags:compact.unrelatedRuntimeFlags,pipelineState:compact.pipelineState}:null}:null;
                      b.samples.push({budget:options.imageTokens,elapsedMs:completedAt-start,startedAt:start,completedAt,hash:hash>>>0,
                        stageTiming,prefixReuse,visionFusion,visionQkv});
                      return result;
                    } finally {b.inFlight--;}
                  };
                }""")
                phases = []
                output["phases"] = phases
                for index, mode in enumerate(BLOCK_MODES):
                    budget = args.budget
                    warmups = WARMUPS_PER_BLOCK[index]
                    captured_count = args.frames + warmups
                    if index:
                        page.locator('[data-act="stop"]').click()
                        page.wait_for_function("window.cameraBench.inFlight===0", timeout=remaining_ms())
                        page.wait_for_function("()=>window.cameraBench.streams.at(-1)?.getTracks().every(track=>track.readyState==='ended')", timeout=remaining_ms())
                    control = "visionqkv-on" if mode == "on" else "visionqkv-off"
                    supported = page.evaluate("async mode => (await import('./app/session.js')).session.kevala.profile(mode)", control)
                    if not supported:
                        raise RuntimeError("the paired proxy did not acknowledge vision-qkv control")
                    before = page.evaluate("window.cameraBench.samples.length")
                    page.evaluate("phase => {const b=window.cameraBench;b.currentPhase=String(phase);b.preview[String(phase)]={timestamps:[],presentedFrames:0,droppedTimestamps:0,watching:false};}", index)
                    page.locator('[data-f="resolution"]').select_option(str(budget))
                    page.locator('[data-act="start"]').click()
                    page.wait_for_function(
                        "([before,budget,count])=>window.cameraBench.samples.slice(before).filter(x=>x.budget===budget).length>=count",
                        arg=[before, budget, captured_count], timeout=remaining_ms(),
                    )
                    phase = page.evaluate("""([before,budget,count,phaseIndex])=>({budget,
                      samples:window.cameraBench.samples.slice(before).filter(x=>x.budget===budget).slice(0,count),
                      displayedFps:document.querySelector('[data-f="fps"]').textContent,
                      displayedLatency:document.querySelector('[data-f="latency"]').textContent,
                      resolution:document.querySelector('[data-f="frame-label"]').textContent,
                      videoSize:[document.querySelector('video').videoWidth,document.querySelector('video').videoHeight],
                      trackSettings:document.querySelector('video').srcObject.getVideoTracks()[0].getSettings(),
                      preview:window.cameraBench.preview[String(phaseIndex)],
                      selectedTuning:window.cameraBench.selectedTuning,
                      currentTuning:JSON.stringify(window.cameraBench.model.info?.gpuTuning||{})})""", [before, budget, captured_count, index])
                    phase["block"] = index
                    phase["quad"] = index // 4
                    phase["warmupFrames"] = warmups
                    phase["measuredFrames"] = args.frames
                    phase["visionQkvMode"] = mode
                    phase["mode"] = mode
                    phases.append(phase)
                page.locator('[data-act="stop"]').click()
                page.wait_for_function("window.cameraBench.inFlight===0", timeout=remaining_ms())
                page.wait_for_function("()=>document.querySelector('[data-f=video]').srcObject===null&&window.cameraBench.streams.length===16&&window.cameraBench.streams.every(s=>s.getTracks().every(t=>t.readyState==='ended'))", timeout=remaining_ms())
                checks = page.evaluate("""async ()=>{
                  const {session}=await import('./app/session.js');
                  return {maxInFlight:window.cameraBench.maxInFlight,
                    sameModel:session.kevala===window.cameraBench.model,
                    videoCleared:document.querySelector('[data-f="video"]').srcObject===null,
                    tracksStopped:window.cameraBench.streams.length>0&&window.cameraBench.streams.every(s=>s.getTracks().every(t=>t.readyState==='ended')),
                    streamCount:window.cameraBench.streams.length,
                    lastTab:document.querySelector('.tabs-nav a:last-child').dataset.route,
                    overflow:document.documentElement.scrollWidth>innerWidth};
                }""")
                if errors or checks["maxInFlight"] != 1 or not checks["sameModel"] or not checks["videoCleared"] or not checks["tracksStopped"] or checks["streamCount"] != 16 or checks["lastTab"] != "reaction" or checks["overflow"]:
                    raise RuntimeError(f"camera checks failed: {checks}, page errors: {errors}")
                unrelated = set()
                fusion_signatures = set()
                batch_state_signatures = set()
                kernel_state_signatures = set()
                tuning_signatures = set()
                for phase in phases:
                    samples = phase["samples"]
                    measured = samples[phase["warmupFrames"]:]
                    if len(samples) != phase["warmupFrames"] + args.frames or len(measured) != MEASURED_PER_BLOCK:
                        raise RuntimeError(f"block {phase['block']} did not capture its explicit warmup and measurement counts")
                    times = [row["elapsedMs"] for row in measured]
                    unique_hashes = len({row["hash"] for row in samples})
                    if unique_hashes < 2:
                        raise RuntimeError("synthetic camera frames did not change")
                    expected_enabled = phase["mode"] == "on"
                    if any(not row["visionQkv"] for row in samples):
                        raise RuntimeError(f"vision-qkv fusion metadata is missing in {phase['mode']}")
                    actual_compact = {row["visionQkv"]["enabled"] for row in samples}
                    actual_preprocesses = {row["visionQkv"]["fusionCount"] for row in samples}
                    submit_modes = {row["visionQkv"]["submitMode"] for row in samples}
                    if actual_compact != {expected_enabled} or actual_preprocesses != {16 if expected_enabled else 0} or submit_modes != {"split"}:
                        raise RuntimeError(f"vision-qkv fusion branch/count or split submission mismatch in {phase['mode']}: enabled={actual_compact}, counts={actual_preprocesses}, submitModes={submit_modes}")
                    if any(row["visionQkv"].get("actualRows") != 108 or row["visionQkv"].get("actualSoftRows") != 12 or row["visionQkv"].get("paddedPatchMetadata") != 144 for row in samples):
                        raise RuntimeError("unexpected compact camera geometry")
                    if any(row["visionQkv"]["imageCount"] != 1 for row in samples):
                        raise RuntimeError(f"camera phase {phase['mode']} did not process one image per decision")
                    if phase["selectedTuning"] != phase["currentTuning"]:
                        raise RuntimeError("GPU tuning selections changed during the camera phase")
                    tuning_signatures.add(phase["currentTuning"])
                    reported_camera_fps = phase["trackSettings"].get("frameRate")
                    if args.camera_fps == 60 and reported_camera_fps is not None and abs(reported_camera_fps - 60) > 1:
                        raise RuntimeError(f"synthetic camera reported {reported_camera_fps} fps, expected 60")
                    for row in measured:
                        prefix_counts = tuple(row["prefixReuse"][key] for key in ["narrowPrefixMatrices", "prefixGeluFusions", "retiledPrefixMatrices", "sharedMatvecMatrices", "rmsNextFusions"])
                        if any(value is None for value in prefix_counts):
                            raise RuntimeError("vision-submit run omitted an unrelated prefix dispatch counter")
                        if not isinstance(row["visionQkv"]["batchMlpState"], dict) or not isinstance(row["visionQkv"]["kernelSelectionState"], dict) or row["visionFusion"] is None:
                            raise RuntimeError("vision-qkv run omitted batch-MLP, kernel-selection, or vision-fusion state")
                        unrelated.add(prefix_counts)
                        fusion_signatures.add(json.dumps(row["visionFusion"], sort_keys=True))
                        batch_state_signatures.add(json.dumps(row["visionQkv"]["batchMlpState"], sort_keys=True))
                        kernel_state_signatures.add(json.dumps(row["visionQkv"]["kernelSelectionState"], sort_keys=True))
                    preview = phase.pop("preview")
                    timestamps = preview.get("timestamps") or []
                    intervals = [later - earlier for earlier, later in zip(timestamps, timestamps[1:]) if later > earlier]
                    if len(timestamps) < 2 or not intervals:
                        raise RuntimeError(f"video preview cadence was not observed in {phase['mode']}")
                    phase["previewCadence"] = {
                        "observedFrames": len(timestamps),
                        "reportedPresentedFrames": preview.get("presentedFrames", 0),
                        "droppedTimestampSamples": preview.get("droppedTimestamps", 0),
                        "p50IntervalMs": summarize(intervals)["p50Ms"],
                        "p95IntervalMs": summarize(intervals)["p95Ms"],
                        "observedFps": (len(timestamps) - 1) * 1000 / (timestamps[-1] - timestamps[0]),
                    }
                    phase["summary"] = {
                        "discardedWarmups": phase["warmupFrames"],
                        "measuredDecisions": len(measured),
                        "decisionWall": summarize(times),
                        "measuredSpanMs": measured[-1]["completedAt"] - measured[0]["startedAt"],
                        "completedFps": len(measured) * 1000 / (measured[-1]["completedAt"] - measured[0]["startedAt"]),
                        "completionTimePerDecisionMs": (measured[-1]["completedAt"] - measured[0]["startedAt"]) / len(measured),
                        "visionQkvFusionCounts": sorted(actual_preprocesses),
                        "submitModes": sorted(submit_modes),
                        "imageStages": {key: summarize([row["stageTiming"].get(key) for row in measured]) for key in ["decode", "preprocess", "forward"]},
                        "uniqueSyntheticFrameHashes": unique_hashes,
                        "previewCadence": phase["previewCadence"],
                    }
                    phase["samples"] = samples
                if len(unrelated) != 1 or len(fusion_signatures) != 1 or len(batch_state_signatures) != 1 or len(kernel_state_signatures) != 1 or len(tuning_signatures) != 1:
                    raise RuntimeError("unrelated kernel selections or counters changed across vision-qkv phases")
                aggregate = aggregate_blocks(phases)
                if len(phases) != 16 or any(aggregate["byMode"][mode]["measuredDecisions"] != 480 for mode in ["off", "on"]) or len(aggregate["balancedQuads"]) != 4:
                    raise RuntimeError("balanced benchmark did not produce sixteen blocks and480 measured decisions per mode")
                output.update(status="done", experiment="same-model joint BF16 vision Q/K/V fusion balanced ABBA x4", unrelatedDispatchesConstant=True,
                    kernelSelectionsConstant=True, visionFusionStatsConstant=True, batchMlpStateConstant=True,
                    splitSubmissionConstant=True,
                    browser=context.browser.version, info=info, phases=phases, checks=checks, pageErrors=errors,
                    cameraCadenceHz=args.camera_fps, aggregate=aggregate)
                page.evaluate("async () => (await import('./app/session.js')).session.kevala.dispose()")
            finally:
                context.close()
    except Exception as error:
        output.update(status="error", error=str(error))
        raise
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
        signal.signal(signal.SIGALRM, previous_handler)
        output["jobElapsedSeconds"] = time.monotonic() - started
        output["finalResourceSnapshot"] = cgroup_resources()
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"status": output["status"], "aggregate": output["aggregate"], "phases": [{"block": row["block"], "quad": row["quad"], "mode": row["mode"], "budget": row["budget"], **row["summary"]} for row in output["phases"]]}))


if __name__ == "__main__":
    main()
