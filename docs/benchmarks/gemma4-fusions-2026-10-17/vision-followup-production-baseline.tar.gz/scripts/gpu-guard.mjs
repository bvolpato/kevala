// GPU numerical guards: every kernel compiles, the kernels match their CPU references, and the
// models match their PyTorch fixtures on WebGPU. Start scripts/serve.mjs and download the local
// packs first. A check whose GPU feature this device lacks is recorded as skipped.
import { mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { BASE_URL, failed, runPage } from "./lib/browser-run.mjs";

const out = resolve(process.argv[2] || "tmp/gpu-guard");
mkdirSync(out, { recursive: true });
const registry = readFileSync(new URL("../crates/kevala/src/gpu.rs", import.meta.url), "utf8").match(/pub const KERNELS:.*?= &\[([\s\S]*?)\];/)?.[1];
const kernels = [...(registry || "").matchAll(/"([a-z0-9_]+)"/g)].map((match) => match[1]);
if (!kernels.length) throw new Error("GPU kernel registry is empty");
const compilePath = `/dev/kernel-compile-check.html?kernels=${encodeURIComponent(kernels.join(","))}`;
const checks = [
  ["compile", "gpu", compilePath],
  ["compile-baseline", "gpu", `${compilePath}&baseline=1`],
  ["activations", "gpu", "/dev/activation-check.html"],
  ["tiles", "gpu", "/dev/gpu-bench.html?cases=7x132x96,17x132x96,45x132x96,45x132x1024&samples=3&warmups=1"],
  ...["bf16", "f32", "q8"].map((weights) => [`weights-${weights}`, "gpu", `/dev/gpu-bench.html?weights=${weights}&gather=1&cases=7x132x96,45x132x1024&kernels=matmul@256:4,matmul_wide@256:4&samples=3&warmups=1`]),
  ["gemma-matvec", "gpu", "/dev/gemma4-matvec-check.html"],
  ["gemma-matvec-gelu", "gpu", "/dev/gemma4-matvec-gelu-check.html"],
  ["gemma-two-row-subgroup", "gpu", "/dev/gemma4-matvec-two-subgroup-check.html?strategy=vector&registered=1", undefined, ["subgroup32", "timestampQuery"]],
  ["gemma-batch-tall", "gpu", "/dev/gemma4-suffix-tall-check.html?tile=104&registered=1&f16=1", undefined, ["shaderF16", "timestampQuery"]],
  ["gemma-batch-single-tall", "gpu", "/dev/gemma4-matmul-f16-tall-check.html", undefined, ["shaderF16", "timestampQuery"]],
  ["gemma-batch-validation", "gpu", "/dev/gemma4-batch-validation-check.html"],
  ["gemma-ple-reduce", "gpu", "/dev/gemma4-ple-gelu-check.html?registered=1", undefined, ["timestampQuery"]],
  ["gemma-matmul-gelu", "gpu", "/dev/gemma4-matmul-gelu-check.html"],
  ["gemma-rms-fusions", "gpu", "/dev/gemma4-rms-fusion-check.html"],
  ["gemma-rms-fusions-subgroups", "gpu", "/dev/gemma4-rms-fusion-check.html?subgroups=1", undefined, ["subgroup32"]],
  ["gemma-rms-scale-next", "gpu", "/dev/gemma4-rms-scale-next-check.html?registered=1", undefined, ["timestampQuery"]],
  ["gemma-rms-scale-next-subgroups", "gpu", "/dev/gemma4-rms-scale-next-check.html?registered=1&subgroups=1", undefined, ["timestampQuery", "subgroup32"]],
  ["gemma-prefix-bn32", "gpu", "/dev/gemma4-matmul-bn32-check.html?scope=fast&registered=1", undefined, ["timestampQuery"]],
  ["gemma-prefix-gelu-bn32", "gpu", "/dev/gemma4-prefix-gelu-bn32-check.html?registered=1&bounds=all", undefined, ["timestampQuery"]],
  ["row-tiles", "gpu", "/dev/gpu-bench.html?cases=65x68x96,80x132x96,96x70x160,129x68x96,140x132x96,144x70x160&kernels=matmul_h@256:4,matmul_h@256:3&samples=3&warmups=1", undefined, ["shaderF16", "timestampQuery"]],
  ["ordered-sums", "gpu", "/dev/kernel-bench.html?kernels=norm,kev_rms,kev_aprep,gemma4_rms,gemma4_ple&tokens=1,47,128&seed=42&samples=3&warmups=1", undefined, ["subgroup32", "timestampQuery"]],
  ...[2048, 2560, 4096].map((hidden) => [`ordered-rms-${hidden}`, "gpu", `/dev/kernel-bench.html?kernels=kev_rms&kevHidden=${hidden}&tokens=1,47,128&seed=42&samples=3&warmups=1`, undefined, ["subgroup32", "timestampQuery"]]),
  ["kernels", "kernels", "/dev/kernels.html"],
  ["gemma-gelu", "gpu", "/dev/gemma-gelu-check.html"],
  ["gemma-attention", "gpu", "/dev/gemma-attn-bench.html?samples=1&warmups=1"],
  ["gemma-rms", "gpu", "/dev/gemma-rms-check.html?samples=1&warmups=1"],
  ["gemma-rms-subgroups", "gpu", "/dev/gemma-rms-check.html?subgroups=1&samples=1&warmups=1", undefined, ["subgroup32", "timestampQuery"]],
  ["gemma-tail", "gpu", "/dev/gemma-tail-check.html"],
  ["gemma-vision", "gpu", "/dev/gemma4-vision-check.html"],
  ["gemma-image-preparation", "gpu", "/dev/gemma4-image-gpu-check.html?autorun=1&edges=1&registered=1"],
  ["gemma-vision-op-fusions", "gpu", "/dev/gemma4-vision-check.html?opFusionCheck=1"],
  ["gemma-vision-norm-rope", "gpu", "/dev/gemma4-vision-norm-rope-check.html"],
  ["gemma-vision-pool-norm", "gpu", "/dev/gemma4-vision-pool-norm-check.html"],
  ["gemma-vision-reduce-gelu", "gpu", "/dev/gemma4-vision-reduce-gelu-check.html"],
  ["gemma-vision-reduce-residual", "gpu", "/dev/gemma4-vision-reduce-residual-check.html"],
  ["gemma-vision-attention", "gpu", "/dev/gemma4-vision-attention-check.html"],
  ["gemma-vision-attention-fused", "gpu", "/dev/gemma4-vision-attention-check.html?fused=1"],
  ["gemma-vision-scores", "gpu", "/dev/gemma4-vision-scores-check.html"],
  ["recur4-shared", "gpu", "/dev/recur-check.html?candidate=current&subgroups=0&actual=1&samples=1&warmups=1", undefined, ["timestampQuery"]],
  ["recur8-shared", "gpu", "/dev/recur-check.html?candidate=recur8&subgroups=0&actual=1&samples=1&warmups=1", undefined, ["timestampQuery"]],
  ["recur16-shared", "gpu", "/dev/recur-check.html?candidate=recur16&subgroups=0&actual=1&samples=1&warmups=1", undefined, ["timestampQuery"]],
  ["kev-attention", "gpu", "/dev/kev-attn-bench.html?gateTails=1&samples=1&warmups=1", undefined, ["timestampQuery", "subgroup32"]],
  ["recur4-subgroups", "gpu", "/dev/recur-check.html?candidate=current&subgroups=1&actual=1&samples=1&warmups=1", undefined, ["timestampQuery", "subgroup4"]],
  ["recur8-subgroups", "gpu", "/dev/recur-check.html?candidate=recur8&subgroups=1&actual=1&samples=1&warmups=1", undefined, ["timestampQuery", "subgroup8"]],
  ["recur16-subgroups", "gpu", "/dev/recur-check.html?candidate=recur16&subgroups=1&actual=1&samples=1&warmups=1", undefined, ["timestampQuery", "subgroup16"]],
  ["attention", "gpu", "/dev/attn-bench.html?cases=1:0,15:0,16:0,17:0,31:0,32:0,33:0,63:0,64:0,65:0,127:0,128:0,129:0,47:0,512:0,512:64,150/40:64&kernels=attention,attention_subgroup,attention_tile,attention_tile_shared&samples=1&warmups=1&checks=3"],
  ["laya", "parity", "/parity.html#auto&backend=webgpu&pack=local", "0.024"],
  ["kev", "parity", "/parity-kev.html#backend=webgpu&pack=local", "0.011"],
  ["cache", "cache", "/dev/cache-test.html?backend=webgpu"],
];
let capabilities;
for (const [name, kind, path, tolerance, required = []] of checks) {
  const missing = required.filter((capability) => !capabilities?.[capability]);
  if (missing.length) {
    writeFileSync(resolve(out, `${name}.json`), JSON.stringify({ status: "skipped", missingCapabilities: missing }, null, 2) + "\n");
    console.log(`${name} skipped: missing ${missing.join(", ")}`);
    continue;
  }
  const run = runPage({ result: kind, url: BASE_URL + path, output: resolve(out, `${name}.json`), maxDp: tolerance, cdpDefaultContext: true });
  if (failed(run)) {
    console.error(`${name} failed`, run.error || "");
    process.exit(1);
  }
  if (name === "compile") {
    capabilities = JSON.parse(readFileSync(resolve(out, "compile.json"), "utf8")).capabilities;
    if (!["timestampQuery", "shaderF16", "subgroup4", "subgroup8", "subgroup16", "subgroup32"].every((capability) => typeof capabilities?.[capability] === "boolean")) throw new Error("compile guard did not report device capabilities");
  }
}
console.log("All supported GPU numerical guards passed");
