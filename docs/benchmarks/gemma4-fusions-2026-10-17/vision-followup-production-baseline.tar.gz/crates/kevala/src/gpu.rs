//! The WebGPU kernels. WebGPU only runs WGSL, so every GPU kernel is a `.wgsl` source in
//! `src/wgsl/`, compiled into this crate. This module specializes them for the device and the
//! call site (tile precision, rows and column groups per workgroup, subgroup use, and optionally
//! the matrix shape) and returns the finished source. The browser runtime only turns that source
//! into pipelines and dispatches them.
//!
//! The sources use three directives, each on its own line, plus `{{NAME}}` substitutions:
//!
//! ```text
//! //#include common      the text of common.wgsl, specialized the same way
//! //#if F16              keep the lines up to //#else or //#endif when the flag is set
//! //#else
//! //#endif
//! ```

use crate::json::Value;

/// Every source, embedded at build time. Snippets (`common`, `kev_common`, `splits`) are only
/// ever included by kernels.
const SOURCES: &[(&str, &str)] = &[
    ("common", include_str!("wgsl/common.wgsl")),
    ("ordered_sum", include_str!("wgsl/ordered_sum.wgsl")),
    ("splits", include_str!("wgsl/splits.wgsl")),
    ("matmul", include_str!("wgsl/matmul.wgsl")),
    ("matvec", include_str!("wgsl/matvec.wgsl")),
    ("matvec_gelu", include_str!("wgsl/matvec_gelu.wgsl")),
    ("matvec_two", include_str!("wgsl/matvec_two.wgsl")),
    ("matvec_gelu_two", include_str!("wgsl/matvec_gelu_two.wgsl")),
    ("matmul_k64", include_str!("wgsl/matmul_k64.wgsl")),
    ("matmul_gelu", include_str!("wgsl/matmul_gelu.wgsl")),
    ("matmul_gelu_tall", include_str!("wgsl/matmul_gelu.wgsl")),
    ("matmul_tall", include_str!("wgsl/matmul_tall.wgsl")),
    ("reduce_gelu", include_str!("wgsl/reduce_gelu.wgsl")),
    ("reduce_ple", include_str!("wgsl/reduce_ple.wgsl")),
    ("reduce_ple_gemma_batch", include_str!("wgsl/reduce_ple.wgsl")),
    ("reduce_ple_gemma_source", include_str!("wgsl/reduce_ple.wgsl")),
    ("matmul_gemma_batch", include_str!("wgsl/matmul.wgsl")),
    ("matmul_wide_gemma_batch", include_str!("wgsl/matmul_wide.wgsl")),
    ("reduce_gemma_batch", include_str!("wgsl/reduce.wgsl")),
    ("matmul_gemma_source", include_str!("wgsl/matmul.wgsl")),
    ("matmul_wide_gemma_source", include_str!("wgsl/matmul_wide.wgsl")),
    ("matmul_k64_gemma_source", include_str!("wgsl/matmul_k64.wgsl")),
    ("matmul_bn32_gemma_source", include_str!("wgsl/matmul_bn32.wgsl")),
    ("matmul_gelu_bn32", include_str!("wgsl/matmul_gelu_bn32.wgsl")),
    ("reduce_gemma_source", include_str!("wgsl/reduce.wgsl")),
    ("matmul_wide", include_str!("wgsl/matmul_wide.wgsl")),
    ("reduce", include_str!("wgsl/reduce.wgsl")),
    ("norm", include_str!("wgsl/norm.wgsl")),
    ("rope", include_str!("wgsl/rope.wgsl")),
    ("attention", include_str!("wgsl/attention.wgsl")),
    ("attention_subgroup", include_str!("wgsl/attention_subgroup.wgsl")),
    ("attention_tile", include_str!("wgsl/attention_tile.wgsl")),
    ("attention_tile_f32", include_str!("wgsl/attention_tile_f32.wgsl")),
    ("geglu", include_str!("wgsl/geglu.wgsl")),
    ("gather", include_str!("wgsl/gather.wgsl")),
    ("weight_rows", include_str!("wgsl/weight_rows.wgsl")),
    ("kev_common", include_str!("wgsl/kev_common.wgsl")),
    ("kev_gather", include_str!("wgsl/kev_gather.wgsl")),
    ("kev_rms", include_str!("wgsl/kev_rms.wgsl")),
    ("kev_gates", include_str!("wgsl/kev_gates.wgsl")),
    ("kev_conv", include_str!("wgsl/kev_conv.wgsl")),
    ("kev_save_tail", include_str!("wgsl/kev_save_tail.wgsl")),
    ("kev_qknorm", include_str!("wgsl/kev_qknorm.wgsl")),
    ("kev_recur_lanes", include_str!("wgsl/kev_recur_lanes.wgsl")),
    ("kev_recur_lanes8", include_str!("wgsl/kev_recur_lanes8.wgsl")),
    ("kev_recur_lanes16", include_str!("wgsl/kev_recur_lanes16.wgsl")),
    ("kev_gnorm", include_str!("wgsl/kev_gnorm.wgsl")),
    ("kev_aprep", include_str!("wgsl/kev_aprep.wgsl")),
    ("kev_save_kv", include_str!("wgsl/kev_save_kv.wgsl")),
    ("kev_attention_keys", include_str!("wgsl/kev_attention_keys.wgsl")),
    ("kev_attention", include_str!("wgsl/kev_attention.wgsl")),
    ("kev_attention_tile", include_str!("wgsl/kev_attention_tile.wgsl")),
    ("kev_silumul", include_str!("wgsl/kev_silumul.wgsl")),
    ("gemma4_embed", include_str!("wgsl/gemma4_embed.wgsl")),
    ("gemma4_rms", include_str!("wgsl/gemma4_rms.wgsl")),
    ("gemma4_rms_residual_norm", include_str!("wgsl/gemma4_rms_residual_norm.wgsl")),
    ("gemma4_rms_scale", include_str!("wgsl/gemma4_rms_scale.wgsl")),
    ("gemma4_rms_scale_next", include_str!("wgsl/gemma4_rms_scale_next.wgsl")),
    ("gemma4_qkv", include_str!("wgsl/gemma4_qkv.wgsl")),
    ("gemma4_attention", include_str!("wgsl/gemma4_attention.wgsl")),
    ("gemma4_attention_subgroup", include_str!("wgsl/gemma4_attention_subgroup.wgsl")),
    ("gemma4_gelu", include_str!("wgsl/gemma4_gelu.wgsl")),
    ("gemma4_ple", include_str!("wgsl/gemma4_ple.wgsl")),
    ("gemma4_residual", include_str!("wgsl/gemma4_residual.wgsl")),
    ("gemma4_gather", include_str!("wgsl/gemma4_gather.wgsl")),
    ("gemma4_image_resize_horizontal", include_str!("wgsl/gemma4_image_resize_horizontal.wgsl")),
    ("gemma4_image_resize_vertical", include_str!("wgsl/gemma4_image_resize_vertical.wgsl")),
    ("gemma4_vision_position", include_str!("wgsl/gemma4_vision_position.wgsl")),
    ("gemma4_vision_norm", include_str!("wgsl/gemma4_vision_norm.wgsl")),
    ("gemma4_vision_norm_rope", include_str!("wgsl/gemma4_vision_norm_rope.wgsl")),
    ("gemma4_vision_residual_norm", include_str!("wgsl/gemma4_vision_residual_norm.wgsl")),
    ("gemma4_vision_reduce_residual", include_str!("wgsl/gemma4_vision_reduce_residual.wgsl")),
    ("gemma4_vision_reduce_norm_rope", include_str!("wgsl/gemma4_vision_reduce_norm_rope.wgsl")),
    ("gemma4_vision_clip", include_str!("wgsl/gemma4_vision_clip.wgsl")),
    ("gemma4_vision_rope", include_str!("wgsl/gemma4_vision_rope.wgsl")),
    ("gemma4_vision_scores", include_str!("wgsl/gemma4_vision_scores.wgsl")),
    ("gemma4_vision_scores_tiled", include_str!("wgsl/gemma4_vision_scores_tiled.wgsl")),
    ("gemma4_vision_finite", include_str!("wgsl/gemma4_vision_finite.wgsl")),
    ("gemma4_vision_attention", include_str!("wgsl/gemma4_vision_attention.wgsl")),
    ("gemma4_vision_attention_fused", include_str!("wgsl/gemma4_vision_attention_fused.wgsl")),
    ("gemma4_vision_gelu", include_str!("wgsl/gemma4_vision_gelu.wgsl")),
    ("gemma4_vision_reduce_gelu", include_str!("wgsl/gemma4_vision_reduce_gelu.wgsl")),
    ("gemma4_vision_pool", include_str!("wgsl/gemma4_vision_pool.wgsl")),
    ("gemma4_vision_pool_norm", include_str!("wgsl/gemma4_vision_pool_norm.wgsl")),
];

/// The kernels a runtime can ask for (everything but the snippets).
pub const KERNELS: &[&str] = &[
    "matmul",
    "matvec",
    "matvec_gelu",
    "matvec_two",
    "matvec_gelu_two",
    "matmul_k64",
    "matmul_gelu",
    "matmul_gelu_tall",
    "matmul_tall",
    "reduce_gelu",
    "reduce_ple",
    "reduce_ple_gemma_batch",
    "reduce_ple_gemma_source",
    "matmul_gemma_batch",
    "matmul_wide_gemma_batch",
    "reduce_gemma_batch",
    "matmul_gemma_source",
    "matmul_wide_gemma_source",
    "matmul_k64_gemma_source",
    "matmul_bn32_gemma_source",
    "matmul_gelu_bn32",
    "reduce_gemma_source",
    "matmul_wide",
    "reduce",
    "norm",
    "rope",
    "attention",
    "attention_subgroup",
    "attention_tile",
    "attention_tile_f32",
    "geglu",
    "gather",
    "weight_rows",
    "kev_rms",
    "kev_gather",
    "kev_gates",
    "kev_conv",
    "kev_save_tail",
    "kev_qknorm",
    "kev_recur_lanes",
    "kev_recur_lanes8",
    "kev_recur_lanes16",
    "kev_gnorm",
    "kev_aprep",
    "kev_save_kv",
    "kev_attention_keys",
    "kev_attention",
    "kev_attention_tile",
    "kev_silumul",
    "gemma4_embed",
    "gemma4_rms",
    "gemma4_rms_residual_norm",
    "gemma4_rms_scale",
    "gemma4_rms_scale_next",
    "gemma4_qkv",
    "gemma4_attention",
    "gemma4_attention_subgroup",
    "gemma4_gelu",
    "gemma4_ple",
    "gemma4_residual",
    "gemma4_gather",
    "gemma4_image_resize_horizontal",
    "gemma4_image_resize_vertical",
    "gemma4_vision_position",
    "gemma4_vision_norm",
    "gemma4_vision_norm_rope",
    "gemma4_vision_residual_norm",
    "gemma4_vision_reduce_residual",
    "gemma4_vision_reduce_norm_rope",
    "gemma4_vision_clip",
    "gemma4_vision_rope",
    "gemma4_vision_scores",
    "gemma4_vision_scores_tiled",
    "gemma4_vision_finite",
    "gemma4_vision_attention",
    "gemma4_vision_attention_fused",
    "gemma4_vision_gelu",
    "gemma4_vision_reduce_gelu",
    "gemma4_vision_pool",
    "gemma4_vision_pool_norm",
];

/// What a kernel is specialized for. Kernels ignore the fields they do not use.
#[derive(Clone, Debug, PartialEq)]
pub struct Spec {
    /// Matmul: keep the workgroup tiles in f16 (half the workgroup-memory traffic).
    pub f16: bool,
    /// Stored matrix weights. BF16 expands exactly to F32; F16 only selects tile storage.
    pub weights: WeightType,
    /// Kev attention: reduce inside 32-lane subgroups.
    pub subgroups: bool,
    /// Matmul and reduce: rows per thread, 1 to 4 (a tile covers 16 * rows rows).
    pub rows: u32,
    /// FP32 G1 R4 matmul: cover 56 rows, retaining the virtual 64-row split/grid rule.
    pub row56: bool,
    /// Matmul and reduce: groups of 64 output columns per workgroup, 1 or 2.
    pub groups: u32,
    /// Matmul and reduce: how many workgroups split-K aims for on short inputs.
    pub split_target: u32,
    /// Matmul: N and K compiled in as constants instead of read from the uniform.
    pub shape: Option<(u32, u32)>,
    pub kev: KevSpec,
}

#[derive(Clone, Copy, Debug, PartialEq)]
pub enum WeightType {
    Q8,
    Bf16,
    F32,
}

/// Qwen3.5 text dimensions. The optimized kernels use 256-wide attention heads,
/// 128-wide linear heads, and a four-token convolution.
#[derive(Clone, Debug, PartialEq)]
pub struct KevSpec {
    pub hidden: u32,
    pub heads: u32,
    pub kv_heads: u32,
    pub lin_key_heads: u32,
    pub lin_heads: u32,
    pub rotary: u32,
}

impl Default for KevSpec {
    fn default() -> Self {
        Self { hidden: 1024, heads: 8, kv_heads: 2, lin_key_heads: 16, lin_heads: 16, rotary: 64 }
    }
}

impl Default for Spec {
    fn default() -> Spec {
        Spec {
            f16: false,
            weights: WeightType::Q8,
            subgroups: false,
            rows: 4,
            row56: false,
            groups: 1,
            split_target: 128,
            shape: None,
            kev: KevSpec::default(),
        }
    }
}

impl Spec {
    /// Reads `{ f16, subgroups, rows, row56, groups, splitTarget, n, k }`; missing fields keep their default.
    pub fn from_json(v: &Value) -> Result<Spec, String> {
        let mut s = Spec::default();
        let flag = |key: &str| v.get(key).map(|x| matches!(x, Value::Bool(true)));
        let number = |key: &str| v.get(key).and_then(Value::as_usize).map(|n| n as u32);
        if let Some(f) = flag("f16") {
            s.f16 = f;
        }
        if let Some(w) = v.get("weights") {
            s.weights = match w.as_str() {
                Some("q8") => WeightType::Q8,
                Some("bf16") => WeightType::Bf16,
                Some("f32") => WeightType::F32,
                _ => return Err("weights must be q8, bf16, or f32".into()),
            };
        }
        if let Some(f) = flag("subgroups") {
            s.subgroups = f;
        }
        if let Some(r) = number("rows") {
            s.rows = r;
        }
        if let Some(f) = flag("row56") {
            s.row56 = f;
        }
        if let Some(g) = number("groups") {
            s.groups = g;
        }
        if let Some(t) = number("splitTarget") {
            s.split_target = t;
        }
        if let (Some(n), Some(k)) = (number("n"), number("k")) {
            s.shape = Some((n, k));
        }
        if let Some(v) = v.get("kev") {
            for (key, dst) in [
                ("hidden", &mut s.kev.hidden),
                ("heads", &mut s.kev.heads),
                ("kv_heads", &mut s.kev.kv_heads),
                ("lin_key_heads", &mut s.kev.lin_key_heads),
                ("lin_heads", &mut s.kev.lin_heads),
                ("rotary", &mut s.kev.rotary),
            ] {
                if let Some(n) = v.get(key) {
                    *dst =
                        n.as_usize().and_then(|n| u32::try_from(n).ok()).ok_or_else(|| format!("invalid Kev {key}"))?;
                }
            }
            let k = &s.kev;
            if k.hidden == 0
                || k.hidden > 16384
                || k.hidden % 256 != 0
                || k.heads == 0
                || k.heads > 128
                || k.kv_heads == 0
                || k.heads % k.kv_heads != 0
                || k.lin_key_heads == 0
                || k.lin_key_heads % 2 != 0
                || k.lin_heads == 0
                || k.lin_heads > 128
                || k.lin_heads % k.lin_key_heads != 0
                || k.rotary == 0
                || k.rotary > 256
                || k.rotary % 2 != 0
            {
                return Err("unsupported Qwen3.5 GPU dimensions".into());
            }
        }
        if !(1..=4).contains(&s.rows) {
            return Err(format!("rows must be 1 to 4, not {}", s.rows));
        }
        if !(1..=2).contains(&s.groups) {
            return Err(format!("groups must be 1 or 2, not {}", s.groups));
        }
        Ok(s)
    }

    /// The flags `//#if` tests and the values `{{NAME}}` stands for.
    fn vars(&self) -> Vec<(&'static str, String)> {
        let bm = 16 * self.rows;
        let bn = 64 * self.groups;
        let flag = |on: bool| if on { "1".to_string() } else { String::new() };
        let (n, k) = self.shape.unwrap_or((0, 0));
        vec![
            ("F16", flag(self.f16)),
            ("WEIGHT_Q8", flag(self.weights == WeightType::Q8)),
            ("WEIGHT_BF16", flag(self.weights == WeightType::Bf16)),
            ("WEIGHT_F32", flag(self.weights == WeightType::F32)),
            ("MATVEC_ORDERED", flag(self.f16 && self.weights == WeightType::Q8)),
            ("WIDE_UNROLL", flag(self.f16 && self.rows == 4)),
            ("GENERIC_UNROLL", flag(!self.f16 && self.groups == 1)),
            ("ROWS_GE_2", flag(self.rows >= 2)),
            ("ROWS_GE_3", flag(self.rows >= 3)),
            ("ROWS_GE_4", flag(self.rows >= 4)),
            ("ROW56", flag(self.row56)),
            ("ACC7", flag(self.rows >= 4 && !self.row56)),
            ("SUBGROUPS", flag(self.subgroups)),
            ("SHAPE", flag(self.shape.is_some())),
            ("TILE", if self.f16 { "f16" } else { "f32" }.to_string()),
            ("KEY_BLOCK", if self.f16 { "16" } else { "8" }.to_string()),
            ("KEY_BUFFER_LEN", if self.f16 { "1024" } else { "512" }.to_string()),
            ("ROWS", self.rows.to_string()),
            ("GROUPS", self.groups.to_string()),
            ("BM", bm.to_string()),
            ("PHYSICAL_BM", if self.row56 { 56 } else { bm }.to_string()),
            ("BM_MINUS_1", (bm - 1).to_string()),
            ("BN", bn.to_string()),
            ("BN_MINUS_1", (bn - 1).to_string()),
            ("SPLIT_TARGET", self.split_target.to_string()),
            ("WS_LEN", (8 * bn).to_string()),
            ("WIDE_WS_LEN", (16 * bn).to_string()),
            ("ACC_LEN", (self.rows * self.groups).to_string()),
            ("WV_LEN", (2 * self.groups).to_string()),
            ("N", n.to_string()),
            ("K", k.to_string()),
            ("KEV_HIDDEN", self.kev.hidden.to_string()),
            ("KEV_HEADS", self.kev.heads.to_string()),
            ("KEV_KV_HEADS", self.kev.kv_heads.to_string()),
            ("KEV_LIN_KEY_HEADS", self.kev.lin_key_heads.to_string()),
            ("KEV_LIN_HEADS", self.kev.lin_heads.to_string()),
            ("KEV_ROTARY", self.kev.rotary.to_string()),
            // linear-attention value heads that share key heads (Kev-4B and 9B), not one each
            ("KEV_GROUPED", flag(self.kev.lin_heads != self.kev.lin_key_heads)),
        ]
    }
}

/// The WGSL source of `kernel`, specialized for `spec`.
pub fn wgsl(kernel: &str, spec: &Spec) -> Result<String, String> {
    if !KERNELS.contains(&kernel) {
        return Err(format!("no GPU kernel named {kernel:?}"));
    }
    if kernel == "matmul_gelu_tall"
        && (spec.weights != WeightType::Q8
            || !spec.f16
            || spec.rows != 4
            || spec.groups != 1
            || spec.row56
            || spec.split_target != 256)
    {
        return Err("matmul_gelu_tall requires q8 f16 rows=4 groups=1 row56=false splitTarget=256".into());
    }
    if kernel == "matmul_tall"
        && (spec.weights != WeightType::Q8
            || !spec.f16
            || spec.rows != 4
            || spec.groups != 1
            || spec.row56
            || spec.split_target != 256)
    {
        return Err("matmul_tall requires q8 f16 rows=4 groups=1 row56=false splitTarget=256".into());
    }
    if matches!(kernel, "matmul_bn32_gemma_source" | "matmul_gelu_bn32")
        && (spec.weights != WeightType::Q8
            || spec.f16
            || spec.rows != 2
            || spec.groups != 1
            || spec.row56
            || spec.split_target != 256)
    {
        return Err(format!("{kernel} requires q8 f32 rows=2 groups=1 row56=false splitTarget=256"));
    }
    if matches!(
        kernel,
        "matmul_wide"
            | "matmul_k64"
            | "matmul_wide_gemma_batch"
            | "matmul_wide_gemma_source"
            | "matmul_k64_gemma_source"
            | "matmul_gelu"
            | "reduce_gelu"
    ) && spec.groups != 1
    {
        return Err(format!("{kernel} requires groups=1"));
    }
    if matches!(kernel, "matmul_gelu" | "matvec_two" | "matvec_gelu_two") && spec.weights != WeightType::Q8 {
        return Err(format!("{kernel} requires q8 weights"));
    }
    if kernel == "gemma4_vision_position" && spec.weights == WeightType::Q8 {
        return Err("gemma4_vision_position requires bf16 or f32 weights".into());
    }
    if spec.row56 && (spec.f16 || spec.rows != 4 || spec.groups != 1) {
        return Err("row56 requires f32 rows=4 groups=1".into());
    }
    let mut vars = spec.vars();
    let tall = kernel == "matmul_gelu_tall";
    let physical_bm = if spec.row56 { 56 } else { 16 * spec.rows };
    vars.push(("TALL104", if tall { "1".into() } else { String::new() }));
    vars.push(("MLP_XS_LEN", if tall { 832 } else { 512 }.to_string()));
    vars.push(("MLP_PHYSICAL_BM", if tall { 104 } else { physical_bm }.to_string()));
    vars.push(("MLP_LOAD_ROWS", if tall { 64 } else { physical_bm }.to_string()));
    vars.push((
        "GEMMA_BATCH_SPLIT",
        if kernel.ends_with("_gemma_batch") || kernel == "matmul_tall" { "1".into() } else { String::new() },
    ));
    vars.push(("GEMMA_SOURCE_SPLIT", if kernel.ends_with("_gemma_source") { "1".into() } else { String::new() }));
    let mut out = String::new();
    render(kernel, &vars, &mut out, 0)?;
    Ok(out)
}

/// `wgsl` for a JSON request `{ kernel, ...spec }`, as the WebAssembly runtime asks for it.
pub fn wgsl_json(request: &Value) -> Result<String, String> {
    let kernel = request.get("kernel").and_then(Value::as_str).ok_or("the request names no kernel")?;
    wgsl(kernel, &Spec::from_json(request)?)
}

fn source(name: &str) -> Result<&'static str, String> {
    SOURCES.iter().find(|(n, _)| *n == name).map(|(_, s)| *s).ok_or_else(|| format!("no WGSL source named {name:?}"))
}

fn render(name: &str, vars: &[(&'static str, String)], out: &mut String, depth: usize) -> Result<(), String> {
    if depth > 4 {
        return Err(format!("{name}: includes nest too deeply"));
    }
    let flag = |key: &str| -> Result<bool, String> {
        vars.iter()
            .find(|(k, _)| *k == key)
            .map(|(_, v)| !v.is_empty())
            .ok_or_else(|| format!("{name}: unknown flag {key}"))
    };
    // one entry per open //#if: whether its current branch is kept
    let mut open: Vec<bool> = Vec::new();
    for (number, line) in source(name)?.lines().enumerate() {
        let at = || format!("{name}.wgsl:{}", number + 1);
        let directive = line.trim_start();
        if let Some(key) = directive.strip_prefix("//#if ") {
            open.push(flag(key.trim())?);
            continue;
        }
        if directive == "//#else" {
            let branch = open.last_mut().ok_or_else(|| format!("{}: //#else without //#if", at()))?;
            *branch = !*branch;
            continue;
        }
        if directive == "//#endif" {
            open.pop().ok_or_else(|| format!("{}: //#endif without //#if", at()))?;
            continue;
        }
        if open.iter().any(|kept| !kept) {
            continue;
        }
        if let Some(included) = directive.strip_prefix("//#include ") {
            render(included.trim(), vars, out, depth + 1)?;
            continue;
        }
        out.push_str(&substitute(line, vars).map_err(|e| format!("{}: {e}", at()))?);
        out.push('\n');
    }
    if !open.is_empty() {
        return Err(format!("{name}: //#if without //#endif"));
    }
    Ok(())
}

/// Replaces every `{{NAME}}` in `line` with its value.
fn substitute(line: &str, vars: &[(&'static str, String)]) -> Result<String, String> {
    let mut out = String::with_capacity(line.len());
    let mut rest = line;
    while let Some(start) = rest.find("{{") {
        out.push_str(&rest[..start]);
        let end = rest[start..].find("}}").ok_or("unclosed {{")? + start;
        let key = &rest[start + 2..end];
        let value = vars.iter().find(|(k, _)| *k == key).ok_or_else(|| format!("unknown value {{{{{key}}}}}"))?;
        out.push_str(&value.1);
        rest = &rest[end + 2..];
    }
    out.push_str(rest);
    Ok(out)
}
